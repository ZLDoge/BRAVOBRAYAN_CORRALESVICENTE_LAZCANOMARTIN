from django.contrib import admin
from .models import archivo

# Register your models here.

admin.site.register(archivo)