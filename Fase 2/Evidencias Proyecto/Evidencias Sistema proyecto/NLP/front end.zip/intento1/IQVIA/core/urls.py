from django.urls import path 
from .views import home, form_archivo, calculo

urlpatterns = [
    path('', home, name="home"),
    path('form-archivo', form_archivo, name="form_archivo"),
    path('calculo/', calculo, name="calculo"  )
]    