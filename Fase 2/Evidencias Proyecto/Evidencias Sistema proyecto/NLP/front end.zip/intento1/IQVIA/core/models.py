from django.db import models

# Create your models here.

from django.db import models

class intento1(models.Model):
    correo = models.EmailField(max_length=254)  # Campo de correo electrónico
    documento = models.FileField(upload_to='archivos/')
