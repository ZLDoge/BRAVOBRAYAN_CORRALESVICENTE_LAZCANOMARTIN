from django.contrib import admin
from .models import intento1
# Register your models here.

admin.site.register(intento1)

