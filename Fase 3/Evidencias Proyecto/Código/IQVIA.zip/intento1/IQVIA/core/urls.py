from django.urls import path
from .views import form_archivo, intento, login_view, listado
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path('', login_view, name="home"),
    path('form-archivo', form_archivo, name="form_archivo"),
    path('listado', listado, name="listado"),
    path('intento', intento, name="intento"),# Nueva URL para la página de cálculo
    path('logout/', LogoutView.as_view(next_page='/'), name='logout')

]    