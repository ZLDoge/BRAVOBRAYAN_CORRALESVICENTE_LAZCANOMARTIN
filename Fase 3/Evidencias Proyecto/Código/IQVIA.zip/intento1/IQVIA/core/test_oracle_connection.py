import cx_Oracle

dsn = cx_Oracle.makedsn('127.0.0.1', 1521, service_name='xepdb1')
connection = cx_Oracle.connect(user='IQVIA', password='1234', dsn=dsn)

cursor = connection.cursor()
cursor.execute("SELECT * FROM tabla_madre")
for row in cursor:
    print(row)

cursor.close()
connection.close()
