from django import forms 
from django.forms import ModelForm
from .models import intento1, formu

class archivoform(ModelForm):
    class Meta:
        model = intento1
        fields = ['correo', 'documento']

class formulario(forms.ModelForm):
    class Meta:
        model = formu
        fields = ['correo', 'documento']  


