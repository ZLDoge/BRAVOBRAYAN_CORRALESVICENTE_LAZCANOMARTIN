from django.shortcuts import render, redirect
from .forms import archivoform, formulario
from .models import intento1, formu

# from .utils import comparar_registros, generar_informe 

# Create your views here.
def home(request):
    return render(request, 'home.html')

# def form_archivo(request):
#     success_message = None  # Variable para el mensaje de éxito
    
#     if request.method == 'POST':
#         form = formu(request.POST, request.FILES)
#         if form.is_valid():
#             form.save()
#             success_message = "Archivo y correo subidos correctamente."  # Mensaje de éxito
#             return redirect('prueba')
#         else:
#             # Esto asegura que incluso si el formulario no es válido, devuelva una respuesta
#             return render(request, 'form_archivo.html', {'form': form})
#     else:
#         form = formu()  # Mostrar formulario vacío si la solicitud es GET
    
#     # Siempre se devuelve una respuesta, ya sea para GET o POST
#     return render(request, 'form_archivo.html', {'form': form, 'success_message': success_message})

from django.contrib.auth import authenticate, login
from django.contrib import messages

############Login###################
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)  # Iniciar sesión del usuario (puede ser superusuario)
            return redirect('form_archivo')  # Redirige al área protegida
        else:
            messages.error(request, 'Usuario o contraseña incorrectos.')
    
    return render(request, 'home.html')


def listado(request):
    registros = formu.objects.all()  # Obtener todos los registros del modelo calculo
    return render(request, 'listado.html', {'registros': registros})



def prueba(request):
    return render(request, 'prueba.html')

def intento(request):
    return render(request, 'intento.html')

###############CALCULO######################
from django.shortcuts import render
from django.http import HttpResponse
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from .forms import  archivoform, formulario
import pandas as pd
from io import BytesIO
from fuzzywuzzy import fuzz, process
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.drawing.image import Image
import matplotlib.pyplot as plt
import cx_Oracle
import os


from django.shortcuts import render
from django.http import HttpResponse
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
import pandas as pd
from .models import TablaMadre, Doctor
from .forms import archivoform
from django.db.models import F



from django.shortcuts import render
from django.http import HttpResponse
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from .forms import archivoform
from .models import Doctor, Especialidad
import pandas as pd

def form_archivo(request):
    if request.method == 'POST':
        form = formulario(request.POST, request.FILES)
        if form.is_valid():
            registro = form.save()  # Guarda el formulario y crea un nuevo registro
            archivo1 = registro.documento.path  # Obtiene la ruta del archivo subido

            # Leer el archivo subido como DataFrame
            try:
                df_clientes = pd.read_csv(archivo1)
                print("Contenido del archivo CSV:", df_clientes.head())
                print("Cantidad de filas en clientes:", df_clientes.shape[0])
            except Exception as e:
                return HttpResponse(f"Error leyendo el archivo CSV: {e}", status=400)

            # Verificar si el archivo está vacío
            if df_clientes.empty:
                return HttpResponse("Error: El archivo CSV no contiene datos.", status=400)

            # Obtener datos de la base de datos usando el ORM de Django
            try:
                # Obtener datos de la tabla Doctor
                doctores_queryset = Doctor.objects.values('id_doctor', 'nombre', 'apellido')
                doctores = list(doctores_queryset)

                # Verificar que hay registros en la tabla Doctor
                if not doctores:
                    return HttpResponse("Error: La base de datos no contiene registros para doctores.", status=400)

                # Convertir a DataFrame
                df_doctores = pd.DataFrame(doctores)
                print("DataFrame de Doctores creado:", df_doctores)

                # Obtener datos de la tabla Especialidad
                especialidades_queryset = Especialidad.objects.values('id_especialidad', 'nombre_especialidad')
                especialidades = list(especialidades_queryset)

                # Verificar que hay registros en la tabla Especialidad
                if not especialidades:
                    return HttpResponse("Error: La base de datos no contiene registros para especialidades.", status=400)

                # Convertir a DataFrame
                df_especialidades = pd.DataFrame(especialidades)
                print("DataFrame de Especialidades creado:", df_especialidades)
            except Exception as e:
                return HttpResponse(f"Error obteniendo datos de la base de datos: {e}", status=500)

            # Comparar registros entre el archivo y la base de datos
            # Comparar registros entre el archivo y la base de datos
            try:
                print("Procesando comparación de registros...")

                # Combinar doctores con sus especialidades (si es necesario)
                if not df_especialidades.empty:
                    df_doctores = pd.merge(
                        df_doctores,
                        df_especialidades,
                        left_on='id_doctor',
                        right_on='id_especialidad',  # Ajusta según cómo estén relacionadas las tablas
                        how='left'  # Cambia a 'inner' si necesitas solo registros relacionados
                    )
                    print("DataFrame combinado de Doctores y Especialidades:", df_doctores.head())

                # Realizar la comparación con el archivo subido
                resultados = comparar_registros(df_clientes, df_doctores)
                df_clientes = resultados[0]
                resumen = resultados[1:]  # Obtener cualquier información adicional de la comparación
            except Exception as e:
                return HttpResponse(f"Error procesando los datos: {e}", status=500)


            # Generar el informe
            try:
                informe = generar_informe(df_clientes, *resumen)
                informe_nombre = f'informes/informe_{registro.id}.xlsx'
                ruta_informe = default_storage.save(informe_nombre, ContentFile(informe.getvalue()))

                # Guardar la ruta del informe en el registro
                registro.informe_descarga = ruta_informe
                registro.save()
            except Exception as e:
                return HttpResponse(f"Error generando el informe: {e}", status=500)

            # Enviar el informe como archivo de respuesta
            response = HttpResponse(
                informe, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )
            response['Content-Disposition'] = f'attachment; filename=informe_{registro.id}.xlsx'
            return response
    else:
        # Si no es POST, renderizar el formulario vacío
        form = formulario()

    return render(request, 'form_archivo.html', {'form': form})




# Función para comparar registros

def comparar_registros(clientes, base_datos):
    # Normalizar nombres de columnas para evitar problemas
    clientes.columns = clientes.columns.str.strip().str.title()
    base_datos.columns = base_datos.columns.str.strip().str.title()

    columnas_requeridas = {'Nombre', 'Apellido'}
    faltantes_clientes = columnas_requeridas - set(clientes.columns)
    faltantes_base_datos = columnas_requeridas - set(base_datos.columns)

    if faltantes_clientes:
        raise ValueError(f"El archivo CSV no contiene las columnas necesarias: {faltantes_clientes}")
    if faltantes_base_datos:
        raise ValueError(f"La base de datos no contiene las columnas necesarias: {faltantes_base_datos}")

    if clientes.empty or base_datos.empty:
        raise ValueError("Uno de los DataFrames no contiene datos para procesar.")

    # Convertir a cadenas de texto y rellenar valores nulos
    for col in ['Nombre', 'Apellido']:
        clientes[col] = clientes[col].fillna('').astype(str)
        base_datos[col] = base_datos[col].fillna('').astype(str)

    # Asegurarse de que la columna 'Especialidad' existe en base_datos
    if 'Especialidad' not in base_datos.columns:
        base_datos['Especialidad'] = ''  # Rellenar con valores vacíos si no existe

    clientes['Similitud'] = 0
    clientes['Encontrado'] = 'No'
    clientes['Registro_BBDD'] = ''
    clientes['Sugerencia'] = ''

    for index, cliente in clientes.iterrows():
        nombre_apellido_cliente = f"{cliente['Nombre']} {cliente['Apellido']}"

        mejor_coincidencia = process.extractOne(
            nombre_apellido_cliente,
            (base_datos['Nombre'] + ' ' + base_datos['Apellido']).tolist(),
            scorer=fuzz.token_sort_ratio
        )

        if mejor_coincidencia and mejor_coincidencia[1] >= 80:
            clientes.at[index, 'Similitud'] = mejor_coincidencia[1]
            clientes.at[index, 'Encontrado'] = 'Sí'
            
            # Extraer especialidad solo si existe la coincidencia
            especialidad = base_datos.loc[
                (base_datos['Nombre'] + ' ' + base_datos['Apellido'] == mejor_coincidencia[0]), 'Especialidad'
            ].drop_duplicates().values

            # Manejar el caso en que no haya especialidad
            clientes.at[index, 'Registro_BBDD'] = especialidad[0] if len(especialidad) > 0 else ''
        elif 65 <= mejor_coincidencia[1] < 80:
            clientes.at[index, 'Similitud'] = mejor_coincidencia[1]
            clientes.at[index, 'Sugerencia'] = 'Revisar posible coincidencia'

    total_registros = clientes.shape[0]
    total_encontrados = (clientes['Encontrado'] == 'Sí').sum()
    total_no_encontrados = total_registros - total_encontrados

    porcentaje_encontrados = (total_encontrados / total_registros) * 100
    porcentaje_no_encontrados = 100 - porcentaje_encontrados

    return (clientes, total_registros, total_encontrados, total_no_encontrados,
            round(porcentaje_encontrados, 2), round(porcentaje_no_encontrados, 2))








# Función para generar el informe sin el gráfico
def generar_informe(clientes, total_registros, total_encontrados, total_no_encontrados, porcentaje_encontrados, porcentaje_no_encontrados):
    from tempfile import NamedTemporaryFile
    output = BytesIO()
    wb = Workbook()
    ws = wb.active
    ws.title = "Informe"

    # Configurar título y encabezados
    ws.merge_cells('A1:D1')
    ws['A1'] = 'Puenteo Realizado - IQVIA'
    ws['A1'].font = Font(size=20, bold=True, color='FFFFFF')
    ws['A1'].alignment = Alignment(horizontal="center", vertical="center")
    fill_color_titulo = PatternFill(start_color='0C7BC0', end_color='0C7BC0', fill_type='solid')
    for row in ws['A1:D1']:
        for cell in row:
            cell.fill = fill_color_titulo

    # Encabezados
    encabezados = ['Nombre', 'Apellido', 'Similitud', 'Encontrado', 'Registro_BBDD', 'Sugerencia']
    fill_color = PatternFill(start_color='0C7BC0', end_color='0C7BC0', fill_type='solid')

    for col_num, encabezado in enumerate(encabezados, 1):
        celda = ws.cell(row=3, column=col_num, value=encabezado)
        celda.fill = fill_color
        celda.font = Font(bold=True, color='FFFFFF')
        celda.alignment = Alignment(horizontal="center", vertical="center")

    for r in dataframe_to_rows(clientes[['Nombre', 'Apellido', 'Similitud', 'Encontrado', 'Registro_BBDD', 'Sugerencia']], index=False, header=False):
        ws.append(r)

    # Agregar resumen al final
    ws.append([])  
    ws.append(['Total Registros Procesados', total_registros])
    ws.append(['Total Registros Encontrados', total_encontrados])
    ws.append(['Total Registros No Encontrados', total_no_encontrados])
    ws.append(['Porcentaje Encontrados', f"{porcentaje_encontrados}%"])
    ws.append(['Porcentaje No Encontrados', f"{porcentaje_no_encontrados}%"])

    # Sección del gráfico comentada
    # etiquetas = ['Encontrados', 'No Encontrados']
    # datos = [porcentaje_encontrados, porcentaje_no_encontrados]
    # colores = ['#0C7BC0', '#87CEEB']

    # try:
    #     plt.figure(figsize=(5, 5))
    #     plt.pie(datos, labels=etiquetas, autopct='%1.1f%%', startangle=90, colors=colores, wedgeprops={'edgecolor': 'black'})
    #     plt.title('Distribución de registros encontrados vs no encontrados')

    #     # Crear archivo temporal para la imagen
    #     with NamedTemporaryFile(suffix=".png", delete=False) as tmpfile:
    #         nombre_grafico = tmpfile.name
    #         plt.savefig(nombre_grafico)
    #         plt.close()

    #     # Insertar la imagen en el Excel
    #     img = Image(nombre_grafico)
    #     ws.add_image(img, 'F1')

    #     # Eliminar la imagen después de usarla
    #     os.remove(nombre_grafico)
    # except Exception as e:
    #     print(f"Error generando o insertando el gráfico: {e}")

    wb.save(output)
    output.seek(0)
    return output
